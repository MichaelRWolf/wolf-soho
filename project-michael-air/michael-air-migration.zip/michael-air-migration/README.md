# Michael-air migration and restore record

**Dates:** 2026-08-13 to 2026-08-14  
**Source:** Intel MacBook Pro `Michael-Pro`, water damaged  
**Destination:** Apple Silicon MacBook Air `Michael-air`  
**Restore source:** Time Machine backup on Synology NAS

This is a self-contained handoff for continued work with Claude Code or another coding assistant. All screenshot links are relative to `images/`, so the directory can be moved intact anywhere.

## Executive summary

The replacement Apple Silicon MacBook Air was restored during Setup Assistant from the Time Machine backup of the old Intel MacBook Pro. The restore succeeded. The remaining work is mainly an Intel-to-ARM cleanup plus a Time Machine efficiency audit.

Key unresolved items:

- identify `mmac-shared`;
- account for the **23.42 GB “Other Files & Folders”** category;
- measure how much low-value cache/build/package data was restored;
- decide future Time Machine exclusions based on both **bytes and file count**;
- rebuild developer tooling natively for Apple Silicon;
- repair shell startup and global keyboard-shortcut workflow;
- audit macOS privacy/TCC permissions disturbed by migration.

## 1. Connecting Setup Assistant to the NAS

Setup Assistant reached **Transfer information to this Mac** and offered **Other Server…**.

![Enter Time Machine server](images/01-enter-time-machine-server.jpeg)

The Synology NAS was reachable at:

```text
192.168.8.129
```

A bare `smb://192.168.8.129` initially returned to the source-selection screen without displaying a usable backup.

![No source after bare SMB](images/02-no-source-after-bare-smb.jpeg)

The NAS showed Time Machine-related shares including `Backups-TM-Wolf` and `Backups-TM-Wendy`.

![NAS login and shares](images/03-nas-login-and-shares.jpeg)

A minor setup annoyance: macOS text substitution changed uppercase `TM` into `™` while entering the Time Machine username. Lowercase avoided that substitution.

## 2. Backup OS-version warning

Migration Assistant found the backup but warned that it had been created with macOS 15.7.3 and recommended updating the destination first.

![Newer-backup warning](images/04-newer-backup-update-warning.jpeg)

The update was initially **skipped** because the network containing the NAS had poor Internet, while the location/network with good Internet did not have access to the NAS. Skipping proved that Migration Assistant would still accept the backup.

After migration/login, the preferred order became: update macOS, reboot and verify the base system, then repair Homebrew/shell/Intel-era tooling.

## 3. Migration Assistant inventory

Migration Assistant displayed several account-like entries:

- `MacPorts`
- `Message Bus`
- `mmac-shared`
- `Test User`
- `Annie Nomous`
- `Michael R. Wolf`

![Account inventory](images/05-migration-selection-accounts.jpeg)

The main account and system categories were also visible.

![Main account and system categories](images/06-migration-selection-main-account.jpeg)

These service/legacy accounts had normal-looking home-directory structures (`Library`, `Desktop`, `Documents`, etc.). Some were almost certainly software/service identities rather than human login accounts.

## 4. Final restore selections

| Entry | Selected? | Size shown |
|---|---:|---:|
| Applications | Yes | 17.6 GB |
| MacPorts | No | 0 KB |
| Message Bus | No | 0 KB |
| mmac-shared | Yes | 10.4 MB |
| Test User | No | 0 KB |
| Annie Nomous | Yes | 20.6 MB |
| Michael R. Wolf | Yes | 75.95 GB |
| Other Files & Folders | Yes | 23.42 GB |
| System & Network | Partial | 1.6 MB |
| ↳ System Settings | Yes | 1.6 MB |
| ↳ Printers | No | 0 KB |
| ↳ Network | Yes | 23 KB |

Migration Assistant reported:

- **117 GB selected to transfer**
- **106.22 GB available on Mac after transfer**

Important correction discovered during setup: **“available on Mac” means free space remaining after the selected migration**, not capacity available before migration.

![Final account selections](images/07-final-selections-accounts.jpeg)

![Final System & Network selections](images/08-final-selections-system-network.jpeg)

## 5. Restore performance and small-file behavior

Early in the restore, Migration Assistant reported about **36.6 MB/s** and **45,044 files** transferred.

![Early transfer](images/09-transfer-early-36MBps.jpeg)

Later, throughput fell through roughly 30 → 20 → 10 → 5 MB/s while ETA stayed broadly similar. One screen showed **377,657 files** and **4.5 MB/s**.

![Many-small-files phase](images/10-transfer-many-small-files-4MBps.jpeg)

Interpretation: the bottleneck likely shifted from large-file network throughput to enormous numbers of small files where per-file metadata, permissions, extended attributes, filesystem bookkeeping, and SMB round trips dominate.

After the Mac is stable, inspect the NAS path/interface with:

```sh
route get 192.168.8.129
smbutil statshares -a
```

## 6. Intel → Apple Silicon consequences

The source Mac was Intel; the destination is Apple Silicon.

Useful rule:

- documents/data/preferences are generally architecture-independent;
- ordinary GUI apps may run under Rosetta or be upgraded to Universal/ARM builds;
- package managers, Python environments, compiled libraries, CLI binaries, drivers, extensions, and developer toolchains should be treated as architecture-specific and rebuilt natively.

A successful Migration Assistant copy does not imply an executable is appropriate for Apple Silicon.

## 7. Terminal startup failure

Terminal initially seemed unusable. Clean shells worked, including:

```sh
/bin/zsh -f
```

and a clean Bash invocation.

That proved Terminal.app and the native shells themselves were functional. The failure was in migrated startup/login-shell state.

The configured login shell was found to be:

```text
/usr/local/bin/bash
```

That was the old Homebrew Bash from the Intel Mac. Because it was an Intel executable and Rosetta was not available, Terminal attempted to launch it and immediately failed.

A native immediate fix is:

```sh
chsh -s /bin/zsh
```

After native ARM Homebrew exists, a modern Homebrew Bash could later live under `/opt/homebrew/bin/bash` if desired.

## 8. Intel Homebrew failure

The migrated Homebrew tree is under the Intel prefix:

```text
/usr/local/Homebrew
```

Running it produced:

```text
Bad CPU type in executable
```

The screenshot shows Homebrew's bundled portable Ruby failing for that reason.

![Intel Homebrew failure](images/11-intel-homebrew-bad-cpu.jpeg)

The current architecture was verified as:

```text
arm64
```

Attempting:

```sh
arch -x86_64 /usr/local/bin/brew list
```

also failed, indicating Rosetta was not available at that point.

### Homebrew migration strategy

Do **not** try to convert `/usr/local/Homebrew` into ARM Homebrew, and do not expect `brew cleanup` to solve an architecture migration.

Instead:

1. inventory the old installation without executing it;
2. install fresh native Homebrew under `/opt/homebrew`;
3. reinstall only desired packages;
4. update PATH/startup files;
5. remove the Intel Homebrew tree only after inventory and validation.

Useful inventory commands:

```sh
find /usr/local/Cellar -maxdepth 1 -mindepth 1 -type d -exec basename {} \; | sort
ls /usr/local/Caskroom 2>/dev/null
```

## 9. macOS update before deeper cleanup

After migration/login, Software Update became available.

![Software Update](images/12-software-update.jpeg)

Decision: update macOS before spending significant effort debugging migrated developer tooling, so old factory-OS behavior is not mixed with Intel-to-ARM problems.

## 10. `~/Downloads`: TCC/privacy, not globbing

A symptom initially looked like broken shell globbing. Inside `~/Downloads`:

```text
ls
ls: .: Operation not permitted
```

while:

```sh
ls -ld .
```

successfully described the directory itself.

![Downloads Operation not permitted](images/13-downloads-operation-not-permitted.jpeg)

This strongly suggests macOS privacy/TCC protection rather than ordinary Unix mode/ownership failure.

Follow-up:

- System Settings → Privacy & Security → Files & Folders → Terminal → Downloads
- if needed, inspect Full Disk Access
- quit/reopen Terminal after permission changes

Do not “repair” this with broad `chmod` changes unless later evidence shows actual Unix permission damage.

## 11. `~/Library`: valuable state mixed with garbage

Migration Assistant showed the main account's `Library` at about **27.59 GB** and did not provide a practical way to omit it independently while preserving the account.

`~/Library` mixes valuable state with regenerable junk.

Valuable examples:

- application databases and support data
- preferences
- browser profiles
- Mail/Messages/local databases
- containers and group containers
- key application state

Often-regenerable examples:

- caches
- logs
- indexes
- temporary state
- downloaded package caches
- IDE indexes
- browser caches
- build artifacts
- stale application debris

The goal is **not** “exclude Library.” The goal is to classify its contents by recovery value and regeneration cost.

## 12. Audit `Other Files & Folders` — 23.42 GB

Migration Assistant restored **23.42 GB** under **Other Files & Folders**. This is large enough to deserve an accounting.

Possible sources include:

- `/Users/Shared`
- `/Library`
- `/private`
- package-manager or Unix-style data outside the normal home-directory bucket
- support files and debris from old software

Useful first pass:

```sh
sudo du -xhd 1 / 2>/dev/null | sort -h
sudo du -xhd 1 /Library /Users/Shared /private 2>/dev/null | sort -h
du -xhd 1 ~ | sort -h
```

Then descend into whichever trees are unexpectedly large.

## 13. Investigate `mmac-shared` — 10.4 MB

`mmac-shared` was retained because its origin was unknown. Its size is trivial, but provenance matters.

Inspect its account record:

```sh
dscl . -read /Users/mmac-shared
```

Pay attention to:

- `UniqueID`
- `PrimaryGroupID`
- `NFSHomeDirectory`
- `UserShell`
- real name / aliases

Then inspect the referenced home directory and determine which software created or used it before deleting anything.

## 14. Time Machine efficiency audit

Goal: stop consuming NAS capacity and restore time on data that can be regenerated cheaply.

The important metric is not only **GB**, but also **file count**. A 2 GB cache containing 250,000 files may be much more expensive to back up and restore than a 50 GB directory containing 20 large files.

Initial measurements:

```sh
du -sh ~/Library/Caches
find ~/Library/Caches -type f | wc -l

sudo du -sh /Library/Caches
sudo find /Library/Caches -type f | wc -l
```

Also inspect:

- Homebrew/MacPorts caches and downloads
- Python/pip/uv caches
- reproducible virtual environments
- npm/node caches and generated dependencies
- IDE indexes/caches
- browser caches
- build outputs
- logs and temporary indexes

Desired audit output:

| Category | Size | File count | Recovery value | Regeneration cost | Proposed Time Machine action |
|---|---:|---:|---|---|---|
| Personal documents/projects | TBD | TBD | High | High/impossible | Keep |
| `~/Library/Caches` | TBD | TBD | Near zero | Low | Consider exclude |
| Developer caches | TBD | TBD | Low | Low | Consider exclude |
| Application Support | TBD | TBD | Mixed | Mixed | Inspect |
| `/Users/Shared` | TBD | TBD | Unknown | Unknown | Inspect |
| `/Library` migrated leftovers | TBD | TBD | Mixed | Mixed | Inspect |
| Other Files & Folders | 23.42 GB at migration | TBD | Unknown | Unknown | Account for |
| Intel Homebrew tree | TBD | TBD | Low after inventory | Reinstall | Remove/exclude after rebuild |

Do **not** broadly exclude all of `~/Library`.

## 15. Launcher / keyboard-shortcut recovery

The previous workflow used **Command-Space** for an alternative launcher rather than default Spotlight behavior. Quicksilver was remembered historically, but the immediately-pre-failure launcher should be verified from migrated state instead of guessed.

Before installing a replacement:

1. inspect `/Applications`;
2. inspect relevant preferences under `~/Library/Preferences`;
3. determine whether the active launcher was Quicksilver, Alfred, LaunchBar, Raycast, or another tool;
4. restore Command-Space ownership appropriately.

This is an example of the old computer holding procedural memory that is easy to lose after hardware failure.

## 16. Suggested next-session checklist

1. Finish/update macOS and reboot.
2. Verify configured login shell.
3. Inspect shell startup files before broad edits.
4. Capture an inventory of old Intel Homebrew packages.
5. Install native ARM Homebrew.
6. Repair PATH and shell startup.
7. Investigate `mmac-shared`.
8. Measure `~/Library` by size **and file count** before cleanup.
9. Account for the 23.42 GB **Other Files & Folders**.
10. Identify high-file-count, low-value caches/build artifacts.
11. Decide Time Machine exclusions based on measured recovery value and regeneration cost.
12. Recover launcher/global shortcuts from migrated preferences.
13. Record every cleanup/exclusion decision before deleting data.

## Provenance

This document summarizes the interactive first-boot migration session. It deliberately preserves corrected interpretations as well as successful decisions, because those corrections reveal what Apple's migration UI actually means.
